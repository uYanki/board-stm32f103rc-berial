## Class structure
![class-structure](uml-class.png)
## UI process
![ui-process](uml-ui-process.png)