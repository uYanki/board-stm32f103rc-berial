#ifndef _LED_H_
#define _LED_H_



#include "sys.h"

#define LED0 PCout(13)
//#define LED0 PGout(15)
void LED_init(void);


#endif
