#ifndef __DISPLAY_MONOCHROME_H
#define __DISPLAY_MONOCHROME_H

#include "display_init.h"

void D_init(void);
void D_display(void);
void D_clear(void);
void D_drawPixel(uint8_t x_val, uint8_t y_val, bool show);
void D_setRotate(diaplsy_rotate _val);
void D_setMirror(diaplsy_mirror _val);

extern uint16_t D_Width;
extern uint16_t D_Height;

#endif
