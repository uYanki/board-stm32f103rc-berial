/*abs_addr*/
#include "stm32f10x.h"
#include "stm32f10x_flash.h"
#include <stdio.h>
#include <absacc.h>
#include <io.h>
