#include "display_init.h"

/** SPI Functions  Start**/

void D_WriteByte(uint8_t dat) // SPI发送一个字节
{
    SPI.transfer(dat);
}

void D_WriteBytes(uint8_t *data_list, uint16_t len) // SPI连续发送数据
{
    //    while(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE) == RESET);
    //    DMA_Cmd( DMA1_Channel3, DISABLE);
    //    DMA_Cmd( DMA1_Channel2, DISABLE);
    //
    //    DMA_Tx_Init( DMA1_Channel3, (u32) &SPI1->DATAR, (u32) data_list, len);
    //    DMA_Rx_Init( DMA1_Channel2, (u32) &SPI1->DATAR, (u32) data_list, len);
    //
    //    SPI1->DATAR;
    //
    //    DMA_Cmd( DMA1_Channel3, ENABLE);
    //    DMA_Cmd( DMA1_Channel2, ENABLE);

    //    DMA_Cmd( DMA1_Channel3, DISABLE);
    //    DMA_Tx_Init( DMA1_Channel3, (u32) &SPI1->DATAR, (u32) TxData, Size);
    //    SPI1->DATAR;
    ////    DMA_ClearFlag(DMA1_Channel3, DMA_IT_TCIF5);
    //    DMA_Cmd( DMA1_Channel3, ENABLE);

    for (uint16_t i = 0; i < len; i++)
    {
        //        D_WriteByte(data_list[i]);
        D_WriteByte(*data_list);
        data_list++;
    }

    //    DMA_InitTypeDef DMA_InitStructure;
    //
    //    DMA_DeInit(DMA1_Channel3);
    //    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) &SPI1->DATAR;
    //    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t) data_list; //SPI2_Tx_Buf;
    //    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    //    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    //    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    //    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    //    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    //    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    //    DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
    //    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    //    DMA_Init(DMA1_Channel3, &DMA_InitStructure);
    //
    //    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Tx, ENABLE); //Si24R1模块挂载的SPI_TX使能DMA功能
    //    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Rx, ENABLE); //Si24R1模块挂载的SPI_RX使能DMA功能
    //
    //    DMA_Cmd(DMA1_Channel3, DISABLE);  //关闭DMA1 所指示的通道
    //
    //    DMA_SetCurrDataCounter(DMA1_Channel3, len);  //DMA通道的DMA缓存的大小
    //    //DMA_ClearFlag(DMA1_FLAG_TC5);//清除通道传输完成标志
    //    DMA_ClearITPendingBit(DMA1_IT_TC5);
    //
    //    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Tx, ENABLE);
    //    DMA_ITConfig(DMA1_Channel3, DMA_IT_TC, ENABLE);
    //    DMA_Cmd(DMA1_Channel3, ENABLE);  //使能USART1 TX DMA1 所指示的通道

    // while(RESET == DMA_GetFlagStatus(DMA1_FLAG_TC5));    //判断通道传输完成
    // DMA_ClearFlag(DMA1_FLAG_TC5);//清除通道传输完成标志
}

/** SPI Functions  End**/
