# How messages work for GuiLiteSamples::HostMonitor?

## How real time message(draw waves) work?
![Callstack for drawing waves](draw_wav.png)

## How click button message work?
![Callstack for clicking button](click_button.png)

## How left/right flip message work?
![Callstack for fliping slides](flip.png)