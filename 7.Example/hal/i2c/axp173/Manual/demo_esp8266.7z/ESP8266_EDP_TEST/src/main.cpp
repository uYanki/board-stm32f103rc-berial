#include <Wire.h>
#include <Arduino.h>
#include "AXP173.h"

AXP173 pmu;

#define BUTTON_PIN 0

void setup() {
  Serial.begin(115200);           // start serial for output
  Serial.println("\n");
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  /* Init PMU */
  Wire.begin();
  pmu.begin(&Wire);
  /* Set off time */
  pmu.setPowerOffTime(AXP173::POWEROFF_4S);
  /* Enable and set LDO2 voltage */
  pmu.setOutputEnable(AXP173::OP_LDO2, true);
  pmu.setOutputVoltage(AXP173::OP_LDO2, 3000);
  /* Enable and set LDO3 voltage */
  pmu.setOutputEnable(AXP173::OP_LDO3, true);
  pmu.setOutputVoltage(AXP173::OP_LDO3, 3100);
  /* Enable and set LDO4 voltage */
  pmu.setOutputEnable(AXP173::OP_LDO4, true);
  pmu.setOutputVoltage(AXP173::OP_LDO4, 3200);
  /* Enable and set DCDC1 voltage */
  pmu.setOutputEnable(AXP173::OP_DCDC1, true);
  pmu.setOutputVoltage(AXP173::OP_DCDC1, 3300);
  /* Enable and set DCDC2 voltage */
  pmu.setOutputEnable(AXP173::OP_DCDC2, true);
  pmu.setOutputVoltage(AXP173::OP_DCDC2, 2275);
  /* Enable VBUS ADC */
  pmu.setADCEnable(AXP173::ADC_VBUS_V, true);
  pmu.setADCEnable(AXP173::ADC_VBUS_C, true);
  /* Enable BAT ADC */
  pmu.setADCEnable(AXP173::ADC_BAT_V, true);
  pmu.setADCEnable(AXP173::ADC_BAT_C, true);
  /* Enable charge */
  pmu.setChargeCurrent(AXP173::CHG_450mA);
  // pmu.setChargeLedFre(AXP173::CHARGE_LED_4HZ);
  pmu.setChargeEnable(true);
}

void loop(){
  /* Get PMU info */
  float temp = pmu.getAXP173Temp();
  float vbus_voltage = pmu.getVBUSVoltage();
  float vbus_current = pmu.getVBUSCurrent();
  float bat_voltage = pmu.getBatVoltage();
  float bat_current = pmu.getBatCurrent();
  Serial.printf("temp :%.2f C, vbus_voltage :%.2f V, vbus_current :%.2f mA, bat_voltage :%.2f V, bat_current :%.2f mA\n", temp, vbus_voltage, vbus_current, bat_voltage, bat_current);
  delay(100);
  if(digitalRead(BUTTON_PIN) == LOW) {
    delay(5);
    if (digitalRead(BUTTON_PIN) == LOW)
    {
      pmu.powerOFF();
      while(digitalRead(BUTTON_PIN) == LOW);
    }
  }
}