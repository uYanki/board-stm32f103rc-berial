#ifndef __DISPLAY_DRAWING_H
#define __DISPLAY_DRAWING_H

#include "display_monochrome.h"

void D_drawFill(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, bool show);
void D_drawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, bool show);
void D_drawRectangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, bool show);
void D_drawChar(uint16_t x, uint16_t y, int8_t _data, uint8_t _size);
void D_drawString(uint16_t x, uint16_t y, char *_text, uint8_t _size);
void D_drawChinese(uint16_t x, uint16_t y, uint32_t i);
uint8_t D_drawInt(uint16_t x, uint16_t y, int32_t num, uint8_t _size);
uint8_t D_drawFloat(uint16_t x, uint16_t y, float num, uint8_t precision, uint8_t _size);
void D_drawCircle(uint16_t xc, uint16_t yc, uint16_t r, uint8_t pixel, bool show, bool fill);
void D_drawTriangel(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,
                    bool show);
void D_fillTriangel(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,
                    bool show);

#endif
