<table>
    <tr>
        <td colspan="3"><center><b>Code Size of corePKCS11 (example generated with GCC for ARM Cortex-M)</b></center></td>
    </tr>
    <tr>
        <td><b>File</b></td>
        <td><b><center>With -O1 Optimization</center></b></td>
        <td><b><center>With -Os Optimization</center></b></td>
    </tr>
    <tr>
        <td>core_pkcs11.c</td>
        <td><center>0.8K</center></td>
        <td><center>0.8K</center></td>
    </tr>
    <tr>
        <td>core_pki_utils.c</td>
        <td><center>0.5K</center></td>
        <td><center>0.3K</center></td>
    </tr>
    <tr>
        <td>core_pkcs11_mbedtls.c</td>
        <td><center>8.9K</center></td>
        <td><center>7.5K</center></td>
    </tr>
    <tr>
        <td><b>Total estimates</b></td>
        <td><b><center>10.2K</center></b></td>
        <td><b><center>8.6K</center></b></td>
    </tr>
</table>
