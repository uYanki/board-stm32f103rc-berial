#ifndef __DISPLAY_FPS_H
#define __DISPLAY_FPS_H

#include "display_drawing.h"

#define Diaplsy_Show_FPS 1         // 显示帧数
#define Diaplsy_Compute_Interval 20 //计算函数的间隔

typedef bool (*d_frame_func)(uint16_t frame);
typedef void (*d_compute_func)(uint16_t ms);

/**
 * 提供心跳count为1ms
 * 计算函数(通过定时器按照时间间隔来计算)
 **/
void D_tickInc(uint8_t count, d_compute_func _func);
/**
 * 每帧的绘制函数
 **/
void D_renderFrame(d_frame_func _func);

#endif
