#ifndef __DISPLAY_INIT_H
#define __DISPLAY_INIT_H

#include "display_base.h"

// #define D_SCK(data) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, (data) ? GPIO_PIN_SET : GPIO_PIN_RESET) // SCLK PB13
// #define D_SDA(data) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, (data) ? GPIO_PIN_SET : GPIO_PIN_RESET) // SDA/MOSI  PB15
#define D_DC(data) digitalWrite(D3, data ? HIGH : LOW)  // DC  A3
#define D_CS(data) digitalWrite(D8, data ? HIGH : LOW)  // CS  A2
#define D_RES(data) digitalWrite(D4, data ? HIGH : LOW) // RES A4
#define D_Busy_Read() digitalRead(D2)                   // busy

#define D_Delay(ms) delay(ms)

void D_WriteByte(uint8_t dat);
void D_WriteBytes(uint8_t data_list[], uint16_t len);

#endif
