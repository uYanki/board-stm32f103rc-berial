/*

This is example for SHT3X-ARP Analog Humidity & Temperature Sensors Arduino Library
ClosedCube SHT30A-EASY or ClosedCube SHT31A-PRO breakout modules

Initial Date: 16-Sep-2015

Hardware connections for Arduino Uno:
	VDD to 3.3V DC
	T to A0
	RH to A1
	GND to common groud

MIT License

*/

#include <Wire.h>
#include <ClosedCube_SHT3XA.h>

ClosedCube_SHT3XA sht3xa(3.3, A0, A1);

void setup()
{
	Serial.begin(9600);
	Serial.println("ClosedCube SHT3XA Library Example");
}

void loop()
{
	Serial.print(sht3xa.readTempC());
	Serial.print("C, RH=");
	Serial.print(sht3xa.readHumidity());
	Serial.println("%");

	delay(250);
}
