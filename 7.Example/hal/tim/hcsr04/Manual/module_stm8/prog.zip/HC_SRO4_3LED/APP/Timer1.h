#ifndef __Timer1_H
#define __Timer1_H

void Timer1_Init(void);

#endif