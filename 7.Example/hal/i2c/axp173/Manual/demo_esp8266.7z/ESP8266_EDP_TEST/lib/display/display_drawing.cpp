#include "display_drawing.h"
#include "display_fonts.h"
#include <string.h>
#include <stdio.h>

/** methods start*/

static void drawByte(uint16_t x, uint16_t y, uint8_t chr)
{
    uint8_t i;
    for (i = 0; i < 8; i++)
    {
        if (chr & 0x01)
        {
            D_drawPixel(x, y + i, true);
        }
        chr >>= 1;
    }
}

static char *itoa_my(int32_t value, char *string, int32_t radix)
{
    char zm[12] = "0123456789-";
    char aa[10] = {0};
    int32_t sum = value;
    char *cp = string;
    int32_t i = 0, j = 0;
    if (sum == 0) //处理0的情况
    {
        *cp++ = zm[0];
    }
    else
    {
        if (sum < 0) //处理负数
        {
            *cp++ = zm[10];
            sum *= -1;
        }
        while (sum > 0)
        {
            aa[i++] = zm[sum % radix];
            sum /= radix;
        }

        for (j = i - 1; j >= 0; j--)
        {
            *cp++ = aa[j];
        }
    }
    *cp = '\0';
    return string;
}

static void _swap(uint16_t *a, uint16_t *b)
{
    uint16_t tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}

static void circle_8(uint16_t xc, uint16_t yc, uint16_t x, uint16_t y, bool show)
{
    D_drawPixel(xc + x, yc + y, show);

    D_drawPixel(xc - x, yc + y, show);

    D_drawPixel(xc + x, yc - y, show);

    D_drawPixel(xc - x, yc - y, show);

    D_drawPixel(xc + y, yc + x, show);

    D_drawPixel(xc - y, yc + x, show);

    D_drawPixel(xc + y, yc - x, show);

    D_drawPixel(xc - y, yc - x, show);
}

/** methods end */

void D_drawFill(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, bool show)
{
    uint16_t i, j;
    for (i = x0; i <= x1; i++)
        for (j = y0; j <= y1; j++)
        {
            D_drawPixel(i, j, show);
        }
}

void D_drawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, bool show)
{
    uint16_t t;
    int16_t xerr = 0, yerr = 0, delta_x, delta_y, distance;
    int16_t incx, incy, uRow, uCol;

    delta_x = x1 - x0; //计算坐标增量
    delta_y = y1 - y0;
    uRow = x0;
    uCol = y0;
    if (delta_x > 0)
        incx = 1; //设置单步方向
    else if (delta_x == 0)
        incx = 0; //垂直线
    else
    {
        incx = -1;
        delta_x = -delta_x;
    }
    if (delta_y > 0)
        incy = 1;
    else if (delta_y == 0)
        incy = 0; //水平线
    else
    {
        incy = -1;
        delta_y = -delta_y;
    }
    if (delta_x > delta_y)
        distance = delta_x; //选取基本增量坐标轴
    else
        distance = delta_y;
    for (t = 0; t <= distance + 1; t++) //画线输出
    {
        D_drawPixel(uRow, uCol, show); //画点
        xerr += delta_x;
        yerr += delta_y;
        if (xerr > distance)
        {
            xerr -= distance;
            uRow += incx;
        }
        if (yerr > distance)
        {
            yerr -= distance;
            uCol += incy;
        }
    }
}

void D_drawRectangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, bool show)
{
    D_drawLine(x0, y0, x1, y0, show);
    D_drawLine(x0, y0, x0, y1, show);
    D_drawLine(x0, y1, x1, y1, show);
    D_drawLine(x1, y0, x1, y1, show);
}

void D_drawChar(uint16_t x, uint16_t y, char _data, uint8_t _size)
{
    uint8_t i = _data - 0x20, j, n;
    switch (_size)
    {
#ifdef FontSize5x8
    case FontSize5x8:
        for (j = 0; j < 5; j++)
        {
            drawByte(x + j, y, ascii_table_5x8[i][j]);
        }
        break;
#endif
#ifdef FontSize8x16
    case FontSize8x16:
        for (n = 0; n < 2; n++)
        {
            for (j = 0; j < 8; j++)
            {
                drawByte(x + j, y + 8 * n, ascii_table_8x16[i][j + 8 * n]);
            }
        }
        break;
#endif
    }
}

void D_drawString(uint16_t x, uint16_t y, char *_text, uint8_t _size)
{
    uint8_t i = 0, char_w = (_size == FontSize5x8) ? 6 : 8;
    while (_text[i] > 0x00)
    {
        if ((_text[i] >= 0x20) && (_text[i] < 0x7e))
        {
            D_drawChar(x, y, _text[i], _size);
            i++;
            x += char_w;
        }
        else
            i++;
    }
}

void D_drawChinese(uint16_t x, uint16_t y, uint32_t i)
{
    uint8_t j, n;
    for (n = 0; n < 2; n++)
    {
        for (j = 0; j < 8; j++)
        {
            drawByte(x + j, y + 8 * n, chz_8x16[i][j + 8 * n]);
        }
    }
}

uint8_t D_drawInt(uint16_t x, uint16_t y, int32_t num, uint8_t _size)
{
    char _str[10];
    itoa_my(num, _str, 10);
    D_drawString(x, y, _str, _size);

    return strlen(_str);
}

uint8_t D_drawFloat(uint16_t x, uint16_t y, float num, uint8_t precision, uint8_t _size)
{
    uint8_t int_len = 0, char_w = (_size == FontSize5x8) ? 6 : 8;
    uint32_t sum_base = 1;

    int64_t int_part = (int64_t)num, float_part = 0;

    int_len = D_drawInt(x, y, int_part, _size) * char_w; //输出整数

    if (precision <= 0)
    {
        return int_len / char_w;
    }
    if (precision > 4)
    {
        precision = 4;
    }
    while (precision--)
    {
        sum_base *= 10;
    }
    D_drawChar(x + int_len, y, '.', _size); //显示小数点
    int_len += char_w;

    float_part = (int64_t)(num * sum_base) % sum_base;
    if (float_part < 0)
    {
        float_part = -float_part;
    }
    while ((sum_base /= 10) > 1)
    {
        if (float_part / sum_base > 0)
        {
            break;
        }
        D_drawChar(x + int_len, y, '0', _size); //显示小数点
        int_len += char_w;
    }

    int_len += D_drawInt(x + int_len, y, float_part, _size) * char_w; //显示小数部分

    return int_len / char_w;
}

void D_drawCircle(uint16_t xc, uint16_t yc, uint16_t r, bool show, bool fill)
{
    int32_t x = 0, y = r, yi, d;

    d = 3 - 2 * r;

    if (fill)
    {
        // 如果填充（画实心圆）
        while (x <= y)
        {
            for (yi = x; yi <= y; yi++)
                circle_8(xc, yc, x, yi, show);

            if (d < 0)
            {
                d = d + 4 * x + 6;
            }
            else
            {
                d = d + 4 * (x - y) + 10;
                y--;
            }
            x++;
        }
    }
    else
    {
        // 如果不填充（画空心圆）
        while (x <= y)
        {
            circle_8(xc, yc, x, y, show);
            if (d < 0)
            {
                d = d + 4 * x + 6;
            }
            else
            {
                d = d + 4 * (x - y) + 10;
                y--;
            }
            x++;
        }
    }
}

void D_drawTriangel(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,
                    bool show)
{
    D_drawLine(x0, y0, x1, y1, show);
    D_drawLine(x1, y1, x2, y2, show);
    D_drawLine(x2, y2, x0, y0, show);
}

void D_fillTriangel(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,
                    bool show)
{
    uint16_t a, b, y, last;
    int32_t dx01, dy01, dx02, dy02, dx12, dy12;
    int64_t sa = 0;
    int64_t sb = 0;
    if (y0 > y1)
    {
        _swap(&y0, &y1);
        _swap(&x0, &x1);
    }
    if (y1 > y2)
    {
        _swap(&y2, &y1);
        _swap(&x2, &x1);
    }
    if (y0 > y1)
    {
        _swap(&y0, &y1);
        _swap(&x0, &x1);
    }
    if (y0 == y2)
    {
        a = b = x0;
        if (x1 < a)
        {
            a = x1;
        }
        else if (x1 > b)
        {
            b = x1;
        }
        if (x2 < a)
        {
            a = x2;
        }
        else if (x2 > b)
        {
            b = x2;
        }
        D_drawFill(a, y0, b, y0, show);
        return;
    }
    dx01 = x1 - x0;
    dy01 = y1 - y0;
    dx02 = x2 - x0;
    dy02 = y2 - y0;
    dx12 = x2 - x1;
    dy12 = y2 - y1;

    if (y1 == y2)
    {
        last = y1;
    }
    else
    {
        last = y1 - 1;
    }
    for (y = y0; y <= last; y++)
    {
        a = x0 + sa / dy01;
        b = x0 + sb / dy02;
        sa += dx01;
        sb += dx02;
        if (a > b)
        {
            _swap(&a, &b);
        }
        D_drawFill(a, y, b, y, show);
    }
    sa = dx12 * (y - y1);
    sb = dx02 * (y - y0);
    for (; y <= y2; y++)
    {
        a = x1 + sa / dy12;
        b = x0 + sb / dy02;
        sa += dx12;
        sb += dx02;
        if (a > b)
        {
            _swap(&a, &b);
        }
        D_drawFill(a, y, b, y, show);
    }
}
