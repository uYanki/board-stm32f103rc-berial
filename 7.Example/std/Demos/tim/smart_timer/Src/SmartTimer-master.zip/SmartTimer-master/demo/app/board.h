#ifndef     __BOARD_H__
#define     __BOARD_H__

#include <stm32f10x.h>

#define SYS_LEDPORT      GPIOC
#define SYS_LEDCTRL      GPIO_Pin_10

#endif

