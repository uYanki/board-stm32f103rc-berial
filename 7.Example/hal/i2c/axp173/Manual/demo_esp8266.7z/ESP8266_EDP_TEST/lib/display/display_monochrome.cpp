#include "display_monochrome.h"

/** setting start **/
uint8_t Diaplsy_Rotate = D_Rotate_0;
uint8_t Diaplsy_Mirror = D_Mirror_None;
/** setting end **/

/** buffer start **/
static uint8_t _display_buffer[Draw_Column * Draw_Row];
static uint8_t _write_buffer[Diaplsy_Buffer_Size] = {0};
static uint16_t buffer_index = 0;
/** buffer end **/

uint16_t D_Width = Display_Width;
uint16_t D_Height = Display_Height;

#define DisplayBuffer(_col, _row) _display_buffer[_col + _row * Draw_Column]

void writeCommand(uint8_t _data)
{
    D_DC(0);
    D_CS(0);
    D_WriteByte(_data);
    D_CS(1);
}

void writeCommands(uint8_t _datas[], uint16_t len)
{
    D_DC(0);
    D_CS(0);
    D_WriteBytes(_datas, len);
    D_CS(1);
}

void writeByte(uint8_t _data)
{
    D_DC(1);
    D_CS(0);
    D_WriteByte(_data);
    D_CS(1);
}

void writeBytes(uint8_t _datas[], uint16_t len)
{
    D_DC(1);
    D_CS(0);
    D_WriteBytes(_datas, len);
    D_CS(1);
}

void resetBuffer()
{
    buffer_index = 0;
}

void writeToBuffer(uint8_t _data)
{
    if (buffer_index >= Diaplsy_Buffer_Size)
    {
        writeBytes(_write_buffer, buffer_index);
        buffer_index = 0;
    }
    _write_buffer[buffer_index] = _data;
    buffer_index++;
}

void writeU16ToBuffer(uint16_t _data)
{
    writeToBuffer(_data >> 8);
    writeToBuffer(_data);
}

void sendBufferData()
{
    if (buffer_index > 0)
    {
        writeBytes(_write_buffer, buffer_index);
    }
    buffer_index = 0;
}

#ifdef D_ST7567

void InitCommand() // ST7576
{
    writeCommand(0x0e2);     // soft reset
    writeCommand(0x0ae);     // display off
    writeCommand(0x040 | 0); // set display start line

    // flip : 0xa1 0xc0
    writeCommand(0x0a0); // ADC set to reverse
    writeCommand(0x0c8); // common output mode

    writeCommand(0x0a6); // display normal, bit val 0: LCD pixel off.
    writeCommand(0x0a2); // LCD bias 1/9

    /* power on sequence from paxinstruments */
    writeCommand(0x028 | 4); // all power  control circuits on
    D_Delay(50);
    writeCommand(0x028 | 6); //
    D_Delay(50);
    writeCommand(0x028 | 7); //
    D_Delay(50);

    writeCommand(0x023); // v0 voltage resistor ratio

    writeCommand(0x081); // set contrast, contrast value
    // writeCommand(42>>2);
    // writeCommand(0x0A);
    writeCommand(0xee);
    writeCommand(0x3F & 0x34); //

    writeCommand(0x0af); // display on
}

void D_display()
{
    uint8_t _col, _row;
    uint8_t cmds[] = {0xb0, 0x00, 0x10};

    for (_row = 0; _row < Draw_Row; _row++)
    {
        cmds[0] = 0xb0 + _row;
        writeCommands(cmds, 3);
        resetBuffer();
        for (_col = 0; _col < Draw_Column; _col++)
        {
            writeToBuffer(DisplayBuffer(_col, _row));
        }
        sendBufferData();
    }
}

#elif defined D_ST7302

void InitCommand()
{
    writeCommand(0x38);
    writeCommand(0xEB); // Enable OTP
    writeByte(0x02);
    writeCommand(0xD7); // OTP Load Control
    writeByte(0x68);
    writeCommand(0xD1); // Auto Power Control
    writeByte(0x01);
    writeCommand(0xC0); // Gate Voltage Setting VGH=12V ; VGL=-5V
    writeByte(0x80);
    writeCommand(0xC1); // VSH Setting
    writeByte(0x28);    //
    writeByte(0x28);
    writeByte(0x28);
    writeByte(0x28);
    writeByte(0x14);
    writeByte(0x00);
    writeCommand(0xC2); // VSL Setting VSL=0
    writeByte(0x00);
    writeByte(0x00);
    writeByte(0x00);
    writeByte(0x00);
    writeCommand(0xCB); // VCOMH Setting
    writeByte(0x14);    // 14  0C   7
    writeCommand(0xB4); // Gate EQ Setting HPM EQ LPM EQ
    writeByte(0xE5);
    writeByte(0x77);
    writeByte(0xF1);
    writeByte(0xFF);
    writeByte(0xFF);
    writeByte(0x4F);
    writeByte(0xF1);
    writeByte(0xFF);
    writeByte(0xFF);
    writeByte(0x4F);
    writeCommand(0x11); // Sleep out
    D_Delay(100);       // D_Delay 100ms
    writeCommand(0xC7); // OSC Setting
    writeByte(0xA6);
    writeByte(0xE9);
    writeCommand(0xB0); // Duty Setting
    writeByte(0x64);    // 250duty/4=63
    writeCommand(0x36); // Memory Data Access Control
    writeByte(0x00);
    writeCommand(0x3A); // Data Format Select 4 write for 24 bit
    writeByte(0x11);
    writeCommand(0xB9); // Source Setting
    writeByte(0x23);
    writeCommand(0xB8); // Panel Setting Frame inversion
    writeByte(0x09);
    writeCommand(0x2A); ////Column Address Setting S61~S182
    writeByte(0x05);
    writeByte(0x36);
    writeCommand(0x2B); ////Row Address Setting G1~G250
    writeByte(0x00);
    writeByte(0xC7);
    writeCommand(0xD0);
    writeByte(0x1F);
    writeCommand(0x29); // Display on
    writeCommand(0xB9); // enable CLR RAM
    writeByte(0xE3);
    D_Delay(100);
    writeCommand(0xB9); // enable CLR RAM
    writeByte(0x23);
    writeCommand(0x72);
    writeByte(0x00);    // Destress OFF
    writeCommand(0x39); // LPM
    writeCommand(0x2A); // Column Address Setting
    writeCommand(0x19);
    writeByte(0x23);    // 35
    writeCommand(0x2B); // Row Address Setting
    writeByte(0);
    writeByte(0x7C);
    writeByte(0x2C); // write image data
    D_Delay(120);
}

void setAddress(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
    writeCommand(0x2a);
    writeByte(x1 + 0x19);
    writeByte(x2 + 0x19);
    writeCommand(0x2b);
    writeByte(y1);
    writeByte(y2);
    writeCommand(0x2c);
}

uint8_t getWriteData(uint8_t _data1, uint8_t _data2, uint8_t s_index)
{
    uint8_t data_i = 0, _data;
    int8_t b;
    for (b = (s_index + 3); b >= s_index; b--)
    {
        _data |= ((_data2 & (1 << b)) >> b) << (data_i);
        _data |= ((_data1 & (1 << b)) >> b) << (data_i + 1);
        data_i += 2;
    }

    return _data;
}

void D_display()
{
    int16_t x, y;
    uint8_t get_data1, get_data2, n;

    setAddress(0, 0, Draw_Row / 3 * 2 - 1, Draw_Column);
    resetBuffer();
    for (x = 0; x < (Draw_Column / 2); x++)
    {
        for (y = 0; y < (Draw_Row / 3); y++)
        {
            for (n = 0; n < 3; n++)
            {
                get_data1 = DisplayBuffer(x * 2, y * 3 + n);
                get_data2 = DisplayBuffer(x * 2 + 1, y * 3 + n);

                writeToBuffer(getWriteData(get_data1, get_data2, 0));
                writeToBuffer(getWriteData(get_data1, get_data2, 4));
            }
        }
    }
    sendBufferData();
}

#elif defined D_SH1107

void InitCommand() // SH1107
{
    uint8_t cmds[] = {0xAE, //--turn off oled panel

                      0x00, /*set lower column address*/
                      0x10, /*set higher column address*/

                      0xB0, /*set page address*/

                      0xdc, /*set display start line*/
                      0x00,

                      0x81, /*contract control*/
                      0x6f, /*128*/
                      0x20, /* Set Memory addressing mode (0x20/0x21) */

                      0xA0, /*set segment remap*/
                      0xC0, /*Com scan direction*/
                      0xA4, /*Disable Entire Display On (0xA4/0xA5)*/

                      0xA6, /*normal / reverse*/
                      0xA8, /*multiplex ratio*/
                      0x3F, /*duty = 1/64*/

                      0xD3, /*set display offset*/
                      0x60,

                      0xD5, /*set osc division*/
                      0x41,

                      0xD9, /*set pre-charge period*/
                      0x22,

                      0xdb, /*set vcomh*/
                      0x35,

                      0xad, /*set charge pump enable*/
                      0x8a, /*Set DC-DC enable (a=0:disable; a=1:enable) */
                      // OLED_Clear();
                      0xAF};
    writeCommands(cmds, sizeof(cmds));
    D_clear();
}

void D_display()
{
    uint8_t _col, _row;
    uint8_t cmds[] = {0xb0, 0x00, 0x10};

    for (_row = 0; _row < Draw_Row; _row++)
    {
        cmds[0] = 0xb0 + _row;
        writeCommands(cmds, 3);
        resetBuffer();
        for (_col = 0; _col < Draw_Column; _col++)
        {
            writeToBuffer(DisplayBuffer(_col, _row));
        }
        sendBufferData();
    }
}

#elif defined D_SSD1306

void InitCommand() // SSD1306
{
    writeCommand(0xAE); //--turn off oled panel
    writeCommand(0x00); //---set low column address
    writeCommand(0x10); //---set high column address
    writeCommand(0x40); //--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
    writeCommand(0x81); //--set contrast control register
    writeCommand(0xCF); // Set SEG Output Current Brightness
    writeCommand(0xA1); //--Set SEG/Column Mapping     0xa0???? 0xa1??
    writeCommand(0xC8); // Set COM/Row Scan Direction   0xc0???? 0xc8??
    writeCommand(0xA6); //--set normal display
    writeCommand(0xA8); //--set multiplex ratio(1 to 64)
    writeCommand(0x3f); //--1/64 duty
    writeCommand(0xD3); //-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
    writeCommand(0x00); //-not offset
    writeCommand(0xd5); //--set display clock divide ratio/oscillator frequency
    writeCommand(0x80); //--set divide ratio, Set Clock as 100 Frames/Sec
    writeCommand(0xD9); //--set pre-charge period
    writeCommand(0xF1); // Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
    writeCommand(0xDA); //--set com pins hardware configuration
    writeCommand(0x12);
    writeCommand(0xDB); //--set vcomh
    writeCommand(0x40); // Set VCOM Deselect Level
    writeCommand(0x20); //-Set Page Addressing Mode (0x00/0x01/0x02)
    writeCommand(0x02); //
    writeCommand(0x8D); //--set Charge Pump enable/disable
    writeCommand(0x14); //--set(0x10) disable
    writeCommand(0xA4); // Disable Entire Display On (0xa4/0xa5)
    writeCommand(0xA6); // Disable Inverse Display On (0xa6/a7)
    D_clear();
    D_Delay(100);
    writeCommand(0xAF);
}

void D_display()
{
    uint8_t _col, _row;
    uint8_t cmds[] = {0xb0, 0x00, 0x10};

    for (_row = 0; _row < Draw_Row; _row++)
    {
        cmds[0] = 0xb0 + _row;
        writeCommands(cmds, 3);
        resetBuffer();
        for (_col = 0; _col < Draw_Column; _col++)
        {
            writeToBuffer(DisplayBuffer(_col, _row));
        }
        sendBufferData();
    }
}

#elif defined D_SSD1327

void InitCommand() // SSD1327
{
    D_Delay(500);
    writeCommand(0xae); // Set display off
    writeCommand(0xa0); // Set re-map
    writeCommand(0x66);
    writeCommand(0xa1); // Set display start line
    writeCommand(0x00);
    writeCommand(0xa2); // Set display offset
    writeCommand(0x00);
    writeCommand(0xa4); // Normal Display
    writeCommand(0xa8); // Set multiplex ratio
    writeCommand(0x7f);
    writeCommand(0xab); // Function Selection A
    writeCommand(0x01); // Enable internal VDD regulator
    writeCommand(0x81); // Set contrast
    writeCommand(0x77);
    writeCommand(0xb1); // Set Phase Length
    writeCommand(0x31);
    writeCommand(0xb3); // Set Front Clock Divider /Oscillator Frequency
    writeCommand(0xb1);
    writeCommand(0xb5); //
    writeCommand(0x03); // 0X03 enable
    writeCommand(0xb6); // Set Second pre-charge Period
    writeCommand(0x0d);
    writeCommand(0xbc); // Set Pre-charge voltage
    writeCommand(0x07);
    writeCommand(0xbe); // Set VCOMH
    writeCommand(0x07);
    writeCommand(0xd5); // Function Selection B
    writeCommand(0x02); // Enable second pre-charge
    D_clear();
    D_Delay(100);
    writeCommand(0xaf); // Display on
    D_setMirror(D_Mirror_Horizontal);
    D_setRotate(D_Rotate_270);
}

void D_display()
{
    uint8_t _col, _row, _row_bit, _get_data, _write_data;
    uint8_t cmds[] = {0x75, 0x00, Display_Height - 1, 0x15, 0x00, Display_Width / 2 - 1};
    writeCommands(cmds, 6);
    resetBuffer();
    for (_row = 0; _row < Draw_Row; _row++)
    {
        for (_row_bit = 0; _row_bit < 4; _row_bit++)
        {
            for (_col = 0; _col < Draw_Column; _col++)
            {
                _get_data = DisplayBuffer(_col, _row);
                _write_data = 0;
                if (_get_data & (0x01 << _row_bit * 2))
                {
                    _write_data = 0xf0;
                }
                if (_get_data & (0x01 << (_row_bit * 2 + 1)))
                {
                    _write_data |= 0x0f;
                }
                writeToBuffer(_write_data);
            }
        }
    }
    sendBufferData();
}

#elif defined D_EPD_2in13bc

void readBusy(void)
{
    // while (1)
    // {
    //     //=1 BUSY
    //     if (D_Busy_Read() == 0)
    //         break;
    //     D_Delay(10);
    // }
    // D_Delay(10);
}

void InitCommand() // SH1107
{
    writeCommand(0x06); // BOOSTER_SOFT_START
    writeByte(0x17);
    writeByte(0x17);
    writeByte(0x17);

    writeCommand(0x04); // POWER_ON
    readBusy();

    writeCommand(0x00); // PANEL_SETTING
    writeByte(0x8F);

    writeCommand(0x50); // VCOM_AND_DATA_INTERVAL_SETTING
    writeByte(0xF0);
    writeCommand(0x61);            // RESOLUTION_SETTING
                                   // writeByte(Display_Width);       // width: 104
                                   // writeByte(Display_Height >> 8); // height: 212
                                   // writeByte(Display_Height & 0xFF);
    writeByte(Display_Height);     // width: 104
    writeByte(Display_Width >> 8); // height: 212
    writeByte(Display_Width & 0xFF);
    // D_setRotate(D_Rotate_90);
    D_setMirror(D_Mirror_Vertical);
}

void turnOnDisplay(void)
{
    writeCommand(0x12); // DISPLAY REFRESH
    D_Delay(10);

    readBusy();
}

uint8_t getWriteData(uint8_t _val)
{
    uint8_t temp = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
        temp |= ((_val & 0x01 << i) >> i) << (7 - i);
    }

    return temp;
}

void D_display()
{
    uint16_t _width = (Display_Width % 8 == 0) ? (Display_Width / 8) : (Display_Width / 8 + 1);
    uint16_t _height = Display_Height;
    // black color
    writeCommand(0x10);
    resetBuffer();
    // for (uint8_t _row = 0; _row < Draw_Row; _row++)
    // {
    //     for (int8_t _row_bit = 0; _row_bit < 8; _row_bit++)
    //     {
    //         uint8_t bit_index = 0;
    //         int8_t wdata = 0x00;
    //         for (uint8_t _col = 0; _col < Draw_Column; _col++)
    //         {
    //             if (bit_index >= 8)
    //             {
    //                 bit_index = 0;
    //                 writeToBuffer(~wdata);
    //                 wdata = 0x00;
    //             }
    //             int8_t witem = DisplayBuffer(_col, _row);
    //             // wdata |= (witem & (0x01 << _row_bit) >> _row_bit) << (7 - _row_bit);
    //             wdata = witem;
    //             bit_index++;
    //         }
    //         if (bit_index > 0)
    //         {
    //             writeToBuffer(~wdata);
    //         }

    //         // for (uint8_t w = 0; w < _width; w++)
    //         // {
    //         //     uint8_t wdata = 0x00;
    //         //     for (uint8_t k = 0; k < 8; k++)
    //         //     {
    //         //         uint8_t x = w * 8 + k;
    //         //         if (x >= Draw_Column)
    //         //         {
    //         //             break;
    //         //         }
    //         //         uint8_t witem = _display_buffer[x][y];
    //         //         wdata |= (witem & (0x01 << y_bit) >> y_bit) << (7 - y_bit);
    //         //         // wdata |= witem & (0x01 << y_bit);
    //         //     }

    //         //     writeToBuffer(~wdata);
    //         // }
    //     }
    // }

    for (uint8_t _col = 0; _col < Draw_Column; _col++)
    {
        for (uint8_t _row = 0; _row < Draw_Row; _row++)
        {
            writeToBuffer(getWriteData(~DisplayBuffer(_col, _row)));
        }
    }

    sendBufferData();
    writeCommand(0x92);

    // red color
    writeCommand(0x13);
    resetBuffer();
    for (uint8_t j = 0; j < _height; j++)
    {
        for (uint8_t i = 0; i < _width; i++)
        {
            writeToBuffer(0xff);
        }
    }
    sendBufferData();
    writeCommand(0x92);

    turnOnDisplay();
}

#elif defined D_EPD_2in13

void readBusy(void)
{
    while (1)
    {
        //=1 BUSY
        if (D_Busy_Read() == 0)
            break;
        D_Delay(10);
    }
    D_Delay(10);
}

void InitCommand() // SH1107
{
    readBusy();
    writeCommand(0x12); // SWRESET
    readBusy();

    writeCommand(0x01); // Driver output control
    writeByte(0x27);
    writeByte(0x01);
    writeByte(0x01);

    writeCommand(0x11); // data entry mode
    writeByte(0x01);

    writeCommand(0x44); // set Ram-X address start/end position
    writeByte(0x00);
    writeByte(0x0F); // 0x0F-->(15+1)*8=128

    writeCommand(0x45); // set Ram-Y address start/end position
    writeByte(0x27);    // 0xF9-->(249+1)=250
    writeByte(0x01);
    writeByte(0x00);
    writeByte(0x00);

    writeCommand(0x3C); // BorderWavefrom
    writeByte(0x05);

    writeCommand(0x21); //  Display update control
    writeByte(0x00);
    writeByte(0x80);

    writeCommand(0x18); // Read built-in temperature sensor
    writeByte(0x80);

    writeCommand(0x4E); // set RAM x address count to 0;
    writeByte(0x00);
    writeCommand(0x4F); // set RAM y address count to 0X199;
    writeByte(0x27);
    writeByte(0x01);

    writeCommand(0x61);            // RESOLUTION_SETTING
                                   // writeByte(Display_Width);       // width: 104
                                   // writeByte(Display_Height >> 8); // height: 212
    writeByte(Display_Height);     // width: 104
    writeByte(Display_Width >> 8); // height: 212
    writeByte(Display_Width & 0xFF);
    // D_setRotate(D_Rotate_90);
    //    D_setMirror(D_Mirror_Vertical);

    readBusy();
}

void turnOnDisplay(void)
{

    writeCommand(0x22); // Display Update Control
    writeByte(0xF7);
    // writeByte(0xFF);
    writeCommand(0x20); // Activate Display Update Sequence

    readBusy();
}

uint8_t getWriteData(uint8_t _val)
{
    uint8_t temp = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
        temp |= ((_val & 0x01 << i) >> i) << (7 - i);
    }

    return temp;
}

// void D_display() {
//     uint8_t _col, _row;
//
//     writeCommand(0x24);
//     resetBuffer();
//     for (_row = 0; _row < Draw_Row; _row++) {
//         for (_col = 0; _col < Draw_Column; _col++) {
//             writeToBuffer(DisplayBuffer(_col, _row));
//         }
//         sendBufferData();
//     }
//     sendBufferData();
//
//     turnOnDisplay();
// }

void D_display()
{
    // black color
    writeCommand(0x24);
    resetBuffer();

    for (uint8_t _col = 0; _col < Draw_Column; _col++)
    {
        for (uint8_t _row = 0; _row < Draw_Row; _row++)
        {
            writeToBuffer(getWriteData(~DisplayBuffer(_col, _row)));
        }
    }

    sendBufferData();
    //    writeCommand(0x92);

    //    // red color
    //    writeCommand(0x13);
    //    resetBuffer();
    //    for (uint8_t j = 0; j < _height; j++)
    //    {
    //        for (uint8_t i = 0; i < _width; i++)
    //        {
    //            writeToBuffer(0xff);
    //        }
    //    }
    //    sendBufferData();
    //    writeCommand(0x92);

    turnOnDisplay();
}

#elif defined D_EPD_1in54

static const unsigned char EPD_1IN54_lut_full_update[] = {0x02, 0x02, 0x01,
                                                          0x11, 0x12, 0x12, 0x22, 0x22, 0x66, 0x69, 0x69, 0x59, 0x58, 0x99, 0x99,
                                                          0x88, 0x00, 0x00, 0x00, 0x00, 0xF8, 0xB4, 0x13, 0x51, 0x35, 0x51, 0x51,
                                                          0x19, 0x01, 0x00};

void readBusy(void)
{
    while (D_Busy_Read() == 1)
    {
        D_Delay(10);
    }
}

static void EPD_SetWindow(uint8_t Xstart, uint8_t Ystart, uint8_t Xend,
                          uint8_t Yend)
{
    writeCommand(0x44); // SET_RAM_X_ADDRESS_START_END_POSITION
    writeByte((Xstart >> 3) & 0xFF);
    writeByte((Xend >> 3) & 0xFF);

    writeCommand(0x45); // SET_RAM_Y_ADDRESS_START_END_POSITION
    writeByte(Ystart & 0xFF);
    writeByte((Ystart >> 8) & 0xFF);
    writeByte(Yend & 0xFF);
    writeByte((Yend >> 8) & 0xFF);
}

/******************************************************************************
 function :  Set Cursor
 parameter:
 ******************************************************************************/
static void EPD_SetCursor(uint8_t Xstart, uint8_t Ystart)
{
    writeCommand(0x4E); // SET_RAM_X_ADDRESS_COUNTER
    writeByte((Xstart >> 3) & 0xFF);

    writeCommand(0x4F); // SET_RAM_Y_ADDRESS_COUNTER
    writeByte(Ystart & 0xFF);
    writeByte((Ystart >> 8) & 0xFF);
}

void InitCommand()
{
    writeCommand(0x01); // DRIVER_OUTPUT_CONTROL
    writeByte((Display_Height - 1) & 0xFF);
    writeByte(((Display_Height - 1) >> 8) & 0xFF);
    writeByte(0x00); // GD = 0; SM = 0; TB = 0;

    writeCommand(0x0C); // BOOSTER_SOFT_START_CONTROL
    writeByte(0xD7);
    writeByte(0xD6);
    writeByte(0x9D);

    writeCommand(0x2C); // WRITE_VCOM_REGISTER
    writeByte(0xA8);    // VCOM 7C

    writeCommand(0x3A); // SET_DUMMY_LINE_PERIOD
    writeByte(0x1A);    // 4 dummy lines per gate

    writeCommand(0x3B); // SET_GATE_TIME
    writeByte(0x08);    // 2us per line

    writeCommand(0x11);
    writeByte(0x03);

    // set the look-up table register
    writeCommand(0x32);

    for (uint8_t i = 0; i < 30; i++)
    {
        writeByte(EPD_1IN54_lut_full_update[i]);
    }
    D_setRotate(D_Rotate_270);
    D_setMirror(D_Mirror_Vertical);

    readBusy();
}

void turnOnDisplay(void)
{

    writeCommand(0x22); // DISPLAY_UPDATE_CONTROL_2
    writeByte(0xC4);
    writeCommand(0x20); // MASTER_ACTIVATION
    writeCommand(0xFF); // TERMINATE_FRAME_READ_WRITE

    readBusy();
}

uint8_t getWriteData(uint8_t _val)
{
    uint8_t temp = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
        temp |= ((_val & 0x01 << i) >> i) << (7 - i);
    }

    return temp;
}

void D_display()
{
    EPD_SetWindow(0, 0, Display_Width, Display_Height);
    for (uint8_t _col = 0; _col < Draw_Column; _col++)
    {
        EPD_SetCursor(0, _col);
        writeCommand(0x24);
        resetBuffer();
        for (uint8_t _row = 0; _row < Draw_Row; _row++)
        {
            writeToBuffer(getWriteData(~DisplayBuffer(_col, _row)));
        }
        sendBufferData();
    }

    turnOnDisplay();
}

#endif

void D_init()
{
    pinMode(D3, OUTPUT);
    pinMode(D4, OUTPUT);
    pinMode(D8, OUTPUT);
    pinMode(D2, INPUT); // BUSY
    SPI.begin();

    D_Delay(100);
    D_RES(0);
    D_Delay(100);
    D_RES(1);
    D_Delay(100);
    D_CS(0);

    InitCommand();
}

void D_clear()
{
    uint8_t _row, _col;
    for (_row = 0; _row < Draw_Row; _row++)
    {
        for (_col = 0; _col < Draw_Column; _col++)
        {
            DisplayBuffer(_col, _row) = 0x00;
        }
    }
}

void D_setRotate(diaplsy_rotate _val)
{
    Diaplsy_Rotate = _val;

    switch (Diaplsy_Rotate)
    {
    case D_Rotate_0:
    case D_Rotate_180:
        D_Width = Display_Width;
        D_Height = Display_Height;
        break;
    case D_Rotate_90:
    case D_Rotate_270:
        D_Width = Display_Height;
        D_Height = Display_Width;
        break;
    }
}

void D_setMirror(diaplsy_mirror _val)
{
    Diaplsy_Mirror = _val;
}

void D_drawPixel(uint8_t x_val, uint8_t y_val, bool show)
{
    uint8_t x = 0, y = 0;
    switch (Diaplsy_Rotate)
    {
    case D_Rotate_0:
        x = x_val;
        y = y_val;
        break;
    case D_Rotate_90:
        x = Display_Width - y_val - 1;
        y = x_val;
        break;
    case D_Rotate_180:
        x = Display_Width - x_val - 1;
        y = Display_Height - y_val - 1;
        break;
    case D_Rotate_270:
        x = y_val;
        y = Display_Height - x_val - 1;
        break;
    }
    switch (Diaplsy_Mirror)
    {
    case D_Mirror_None:
        break;
    case D_Mirror_Horizontal:
        x = Display_Width - x - 1;
        break;
    case D_Mirror_Vertical:
        y = Display_Height - y - 1;
        break;
    case D_Mirror_Origin:
        x = Display_Width - x - 1;
        y = Display_Height - y - 1;
        break;
    }

    if (x > Display_Width || y > Display_Height)
    {
        return;
    }
    else
    {
        if (show)
        {
            DisplayBuffer(x, y / 8) |= (1 << (y % 8));
        }
        else
        {
            DisplayBuffer(x, y / 8) &= ~(1 << (y % 8));
        }
    }
}
