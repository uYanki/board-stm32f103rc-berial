#ifndef __TIMER2_H
#define __TIMER2_H

void Timer2_Init(void);

#endif