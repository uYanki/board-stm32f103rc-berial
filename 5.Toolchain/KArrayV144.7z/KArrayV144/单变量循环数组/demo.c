#include  "DebugVisual.h"

//����
DebugVisualdata_t tempVisualdata ;

int main()
{
float tempval;
	
	while(1)
	{
		tempval+=1.0;
		//ִ��
		AddDebugVisual(&tempVisualdata ,tempval);	
	}
}


