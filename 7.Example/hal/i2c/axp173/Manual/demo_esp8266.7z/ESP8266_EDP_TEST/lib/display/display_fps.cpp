#include "display_fps.h"

#define Diaplsy_FPS_Max (1000 / Diaplsy_FPS)

static uint16_t second_tick = 0;
static uint16_t frame_tick = 0;
static uint16_t fps_count = 0;
static uint16_t now_fps = 0;
static bool is_render = false;
static uint16_t compute_interval_tick = 0;

void D_tickInc(uint8_t count, d_compute_func _func) {
    second_tick += count;
    frame_tick += count;
    compute_interval_tick += count;
    if (frame_tick >= Diaplsy_FPS_Max) {
        is_render = true;
        frame_tick = 0;
    }
    if (second_tick >= 1000) {
        now_fps = fps_count;
        second_tick = 0;
        fps_count = 0;
    }
    if (compute_interval_tick >= Diaplsy_Compute_Interval) {
        compute_interval_tick = 0;
        _func(second_tick);
    }
}

void D_drawFPS() {
    D_drawString(0, 0, "FPS:", FontSize5x8);
    D_drawInt(24, 0, now_fps, FontSize5x8);
}

void D_renderFrame(d_frame_func _func) {
    if (is_render) {
        D_clear();
        if (_func(fps_count)) {
#ifdef Diaplsy_Show_FPS
            D_drawFPS();
#endif
            D_display();
            is_render = false;
        }
        fps_count++;
    }
}

