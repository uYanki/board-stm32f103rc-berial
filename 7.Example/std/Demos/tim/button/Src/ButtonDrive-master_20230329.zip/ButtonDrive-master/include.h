#ifndef __INCLUDE_H
#define __INCLUDE_H

/* c ��׼�� */
//#include <stdio.h>
//#include <string.h>
//#include <stdint.h>

/* �ض���ͷ�ļ� */
#include "redef.h"

/* debugͷ�ļ� */
#include "debug.h"




#endif /* __INCLUDE_H */

/********************************END OF FILE***************************************/

