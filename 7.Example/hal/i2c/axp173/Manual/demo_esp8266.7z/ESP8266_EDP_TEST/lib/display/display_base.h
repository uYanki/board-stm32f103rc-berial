#ifndef __DISPLAY_BASE_H
#define __DISPLAY_BASE_H

#include <Arduino.h>
#include <SPI.h>


/** 驱动芯片 **/

// #define D_ST7567 1
// #define D_ST7302 2
// #define D_SH1107 3
// #define D_SSD1306 4
//#define D_SSD1327 5
// #define D_EPD_2in13bc 6
//#define D_EPD_2in13 7
#define D_EPD_1in54 8

/** 旋转角度 **/
typedef enum {
    D_Rotate_0 = 0, D_Rotate_90 = 1, D_Rotate_180 = 2, D_Rotate_270 = 3,
} diaplsy_rotate;

/** 镜像翻转 **/
typedef enum {
    D_Mirror_None = 0,       //不旋转
    D_Mirror_Horizontal = 1, //水平翻转
    D_Mirror_Vertical = 2,   //垂直翻转
    D_Mirror_Origin = 3,     //双向翻转
} diaplsy_mirror;

#define Diaplsy_Buffer_Size (1 * 1024U) // 输出缓冲区大小
#define Diaplsy_FPS 60                  // 帧数

#ifdef D_ST7567

#define Display_Width 128
#define Display_Height 64
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8)

#elif defined D_ST7302

#define Display_Width 250
#define Display_Height 122
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8 + 1)

#elif defined D_SH1107

#define Display_Width 64
#define Display_Height 128
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8)

#elif defined D_SSD1306

#define Display_Width 128
#define Display_Height 64
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8)

#elif defined D_SSD1327

#define Display_Width 128
#define Display_Height 128
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8)

#elif defined D_EPD_2in13bc

#define Display_Width 212
#define Display_Height 104
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8)

#elif defined D_EPD_2in13

#define Display_Width 250
#define Display_Height 122
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8 + 1)

#elif defined D_EPD_1in54

#define Display_Width 200
#define Display_Height 200
#define Draw_Column Display_Width
#define Draw_Row (Display_Height / 8)

#endif

extern uint8_t Diaplsy_Rotate;
extern uint8_t Diaplsy_Mirror;

#define FontSize5x8 0
#define FontSize8x16 1

#endif
