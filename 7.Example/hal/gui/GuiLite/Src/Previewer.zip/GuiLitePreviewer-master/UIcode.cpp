﻿WND_TREE s_main_widgets[] =
{
	{ &s_edit,		ID_EDIT,	"Input",	275, 10, 100, 50},

	{ &s_label_1,	ID_LABEL_1,	"label 1",	150, 100, 100, 50},
	{ &s_label_2,	ID_LABEL_2,	"label 2",	150, 170, 100, 50},
	{ &s_label_3,	ID_LABEL_3,	"label 3",	150, 240, 100, 50},

	{ &s_button,	ID_BUTTON,	"Dialog",	400, 100, 100, 50},
	{ &s_spin_box,	ID_SPIN_BOX,"spinBox",	400, 170, 100, 50},
	{ &s_list_box,	ID_LIST_BOX,"listBox",	400, 240, 100, 50},

	{NULL, 0 , 0, 0, 0, 0, 0}
};
